# Python Crash Course

The code written during lectures and lessons of the Python Crash Course.

# How to use

1. Clone the repository locally
2. Setup an origin to a newly created repository
3. Work on an `exercises/`