if __name__ == "__main__":
    # Do not change 2 lines below
    a = 3.23
    b = 3.72

    # Modify variables a, b to make the script work without errors

    # Do not change the line below
    assert a == b