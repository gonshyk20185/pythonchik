if __name__ == "__main__":
    # Do not change the line below
    a = b = c = d = None

    # Assign the values of correct types to variables a, b, c, d
    a = 5            
    b = 3.14         
    c = 2 + 3j       
    d = "hello"      

    # Do not change the lines below
    assert isinstance(a, int)
    assert isinstance(b, float)
    assert isinstance(c, complex)
    assert isinstance(d, str)
