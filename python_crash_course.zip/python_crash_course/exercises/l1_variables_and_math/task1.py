if __name__ == "__main__":
    # Do not change the line below
    a, b = 10, 5

    # Modify variable `c` to make this script work without errors.
    # Use variables a and b to build a value for variable c
    c = a+b

    # Do not change the line below
    assert c == 15
