if __name__ == "__main__":
    # Do not change the 3 lines below
    a = "name"
    b = "is"
    my = "my"

    # Modify variables `name` and `msg` to make this script work without errors
    # Use variables a, b, my to build a value for variable msg
    name, msg = f my, b, a

    # Do not change the line below
    assert msg == f"My name is {name}"