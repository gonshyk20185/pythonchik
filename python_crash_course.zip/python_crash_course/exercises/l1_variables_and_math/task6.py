if __name__ == "__main__":
    # Do not change the line below
    a, b, c = 2, 3, 4

    # Compose a value for variable d using variables a, b, c
    # to make the script work without errors
    d = a * a + 2 * b + c

    # Do not change the line below
    assert d == 2 * 2 + 2 * 3 + 4