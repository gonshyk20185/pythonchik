if __name__ == "__main__":
    # Do not change the line below
    s = "Hello World"

    # Modify variable c using string s to make this script work without errors
    c = s[::2]


    # Do not change the line below
    assert c == "HloWrd"
