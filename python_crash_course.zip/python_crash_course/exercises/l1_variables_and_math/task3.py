if __name__ == "__main__":
    # Do not change the line below
    a, b = input("Enter a: "), input("Enter b: ")

    # Modify variables a and b to make the script work without errors
    a=input("Enter a: ")
    b=input("Enter b: ")
    # Do not change the line below
    assert a * b
    