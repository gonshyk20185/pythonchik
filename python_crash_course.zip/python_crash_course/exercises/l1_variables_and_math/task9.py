if __name__ == "__main__":
    # Do not change the line below
    l = [1, 2, 5, 0, -3]

    # Modify variable c using list l to make this script work without errors
    c = l[0:2]

    # Do not change the line below
    assert c == [1, 2]
