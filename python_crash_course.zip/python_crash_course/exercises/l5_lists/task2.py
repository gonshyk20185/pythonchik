
if __name__ == "__main__":
    l = [1, 5, 4]

    # Modify the value of variable `c` using
    # list `l` to make the script work without errors
    c = sum(l)

    # Do not change the below's code
    assert c == 10