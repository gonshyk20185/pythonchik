if __name__ == "__main__":
    l = [1, 4, 3, 5, -1, 5]

    # Modify the value of variable `c` using
    # list `l` to make the script work without errors
    c = len(l)
    # Do not change the below's code
    assert c == 6
