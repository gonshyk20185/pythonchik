# Import the function `multiply` from `l2_functions` module
# to make the script work without errors
def multiply(a, b):
    return a * b
# Do not modify the code below
if __name__ == "__main__":
    assert multiply(2, 2) == 4