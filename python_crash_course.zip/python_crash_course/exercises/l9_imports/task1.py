import math 
# Import the required module to make the script work without errors

# Do not modify the code below
if __name__ == "__main__":
    assert math.ceil(3.1) == 4
    assert math.sqrt(4) == 2
    assert math.floor(4.9) == 4
