from math import ceil  
# Import the function `ceil` from package `math` to make the script work without errors

# Do not modify the code below
if __name__ == "__main__":
    assert ceil(4.1) == 5
