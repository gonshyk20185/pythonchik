if __name__ == "__main__":
    # Do not modify the line below
    d = {"a": 1, "b": 2, "c": 42}

    # Retrieve a value from dictionary d to make the script
    # work without errors
    c = d["c"]

    # Do not modify the line below
    assert c == 42
